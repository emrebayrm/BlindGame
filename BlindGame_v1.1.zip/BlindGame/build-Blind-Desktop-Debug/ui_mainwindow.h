/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *UpBut;
    QPushButton *LeftBut;
    QPushButton *RightBut;
    QPushButton *DownBut;
    QLabel *label;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(750, 600);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        UpBut = new QPushButton(centralWidget);
        UpBut->setObjectName(QStringLiteral("UpBut"));
        UpBut->setGeometry(QRect(630, 440, 85, 27));
        LeftBut = new QPushButton(centralWidget);
        LeftBut->setObjectName(QStringLiteral("LeftBut"));
        LeftBut->setGeometry(QRect(580, 470, 85, 27));
        RightBut = new QPushButton(centralWidget);
        RightBut->setObjectName(QStringLiteral("RightBut"));
        RightBut->setGeometry(QRect(670, 470, 85, 27));
        DownBut = new QPushButton(centralWidget);
        DownBut->setObjectName(QStringLiteral("DownBut"));
        DownBut->setGeometry(QRect(630, 500, 85, 27));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(640, 390, 54, 17));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 750, 27));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        UpBut->setText(QApplication::translate("MainWindow", "Up", 0));
        LeftBut->setText(QApplication::translate("MainWindow", "Left", 0));
        RightBut->setText(QApplication::translate("MainWindow", "Right", 0));
        DownBut->setText(QApplication::translate("MainWindow", "Down", 0));
        label->setText(QApplication::translate("MainWindow", "Oyna", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
